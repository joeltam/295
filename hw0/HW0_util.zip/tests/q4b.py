OK_FORMAT = True
import numpy as np

test = {
    "name": "q4b",
    "points": 1,
    "suites": [ 
        {
            "cases": [ 
                {
                    "code": r"""
                    >>> # Check if mats_q4b exists and is a tuple
                    >>> isinstance(mats_q4b, tuple)
                    True
                    >>> # Check if mats_q4b has 3 matrices (A, B, C)
                    >>> len(mats_q4b) == 3
                    True
                    >>> A, B, C = mats_q4b
                    >>> # Check A matrix (2x2)
                    >>> A_correct = np.array([[0, 1], [-1, -0.2]])
                    >>> np.allclose(A, A_correct, rtol=1e-10)
                    True
                    >>> # Check B matrix (2x1)
                    >>> B_correct = np.array([[0], [1]])
                    >>> np.allclose(B, B_correct, rtol=1e-10)
                    True
                    >>> # Check C matrix (1x2)
                    >>> C_correct = np.array([[0, 1]])
                    >>> np.allclose(C, C_correct, rtol=1e-10)
                    True
                    """,
                    "hidden": False,
                    "locked": False,
                }
            ],
            "scored": True,
            "setup": "",
            "teardown": "",
            "type": "doctest"
        }
    ]
}
