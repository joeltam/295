OK_FORMAT = True

test = {
    "name": "q1c",
    "points": 1,
    "suites": [ 
        {
            "cases": [ 
                {
                    "code": r"""
                    >>> # Check if mats_q1c is a numpy array with correct content
                    >>> expected_H = np.array([
                    ...     [2, 6, 0, 0, 0, 0],
                    ...     [3, 9, 0, 0, 0, 0],
                    ...     [0, 0, 1, 2, 0, 0],
                    ...     [0, 0, 3, 4, 0, 0],
                    ...     [0, 0, 0, 0, -5, 5],
                    ...     [0, 0, 0, 0, 5, 3]
                    ... ])
                    >>> isinstance(mats_q1c, np.ndarray) and np.array_equal(mats_q1c, expected_H)
                    True
                    """,
                    "hidden": False,
                    "locked": False,
                }
            ],
            "scored": True,
            "setup": "",
            "teardown": "",
            "type": "doctest"
        }
    ]
}
