OK_FORMAT = True

test = {
    "name": "q1b",
    "points": 1,
    "suites": [ 
        {
            "cases": [ 
                {
                    "code": r"""
                    >>> # Check if mats_q1b is a numpy array with correct content
                    >>> isinstance(mats_q1b, np.ndarray) and np.array_equal(mats_q1b, np.array([[2, 6], [3, 9]]))
                    True
                    """,
                    "hidden": False,
                    "locked": False,
                }
            ],
            "scored": True,
            "setup": "",
            "teardown": "",
            "type": "doctest"
        }
    ]
}
