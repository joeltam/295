OK_FORMAT = True
import numpy as np

test = {
    "name": "q3",
    "points": 1,
    "suites": [ 
        {
            "cases": [ 
                {
                    "code": r"""
                    >>> # Check if function exists
                    >>> callable(compute_series_remainder)
                    True
                    >>> # Check n=5
                    >>> np.isclose(compute_series_remainder(5), 0.181322955737115, rtol=1e-10)
                    True
                    """,
                    "hidden": False,
                    "locked": False,
                }
            ],
            "scored": True,
            "setup": "",
            "teardown": "",
            "type": "doctest"
        }
    ]
}
