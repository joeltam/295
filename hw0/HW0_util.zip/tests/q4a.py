OK_FORMAT = True
import numpy as np

test = {
    "name": "q4a",
    "points": 1,
    "suites": [ 
        {
            "cases": [ 
                {
                    "code": r"""
                    >>> # Check if param_q4a exists and is a tuple
                    >>> isinstance(param_q4a, tuple)
                    True
                    >>> # Check if param_q4a has correct values (R, L, C)
                    >>> R, L, C = param_q4a
                    >>> np.isclose(R, 0.2, rtol=1e-10)  # R = 0.2 ohms
                    True
                    >>> np.isclose(L, 1.0, rtol=1e-10)  # L = 1.0 henries
                    True
                    >>> np.isclose(C, 1.0, rtol=1e-10)  # C = 1.0 farads
                    True
                    """,
                    "hidden": False,
                    "locked": False,
                }
            ],
            "scored": True,
            "setup": "",
            "teardown": "",
            "type": "doctest"
        }
    ]
}
