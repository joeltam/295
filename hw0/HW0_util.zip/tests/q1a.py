OK_FORMAT = True

test = {
    "name": "q1a",
    "points": 1,
    "suites": [ 
        {
            "cases": [ 
                {
                    "code": r"""
                    >>> # Check if mats_q1a is a tuple of three matrices
                    >>> isinstance(mats_q1a, tuple) and len(mats_q1a) == 3
                    True
                    >>> D, E, F = mats_q1a  # Unpack the matrices
                    >>> # Check matrix D
                    >>> isinstance(D, np.ndarray) and np.array_equal(D, np.array([[2, 6, -3], [3, 9, -1]]))
                    True
                    >>> # Check matrix E
                    >>> isinstance(E, np.ndarray) and np.array_equal(E, np.array([[1, 2], [3, 4]]))
                    True
                    >>> # Check matrix F
                    >>> isinstance(F, np.ndarray) and np.array_equal(F, np.array([[-5, 5], [5, 3]]))
                    True
                    """,
                    "hidden": False,
                    "locked": False,
                }
            ],
            "scored": True,
            "setup": "",
            "teardown": "",
            "type": "doctest"
        }
    ]
}
