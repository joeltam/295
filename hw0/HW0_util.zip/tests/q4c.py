OK_FORMAT = True
import numpy as np
from scipy import signal

test = {
    "name": "q4c",
    "points": 1,
    "suites": [ 
        {
            "cases": [ 
                {
                    "code": r"""
                    >>> # Check if sys_q4 exists and is a StateSpace object
                    >>> isinstance(sys_q4, signal.StateSpace)
                    True
                    >>> # Check system matrices
                    >>> np.allclose(sys_q4.A, np.array([[0, 1], [-1, -0.2]]), rtol=1e-10)
                    True
                    >>> np.allclose(sys_q4.B, np.array([[0], [1]]), rtol=1e-10)
                    True
                    >>> np.allclose(sys_q4.C, np.array([[0, 1]]), rtol=1e-10)
                    True
                    >>> np.allclose(sys_q4.D, np.array([[0]]), rtol=1e-10)
                    True
                    """,
                    "hidden": False,
                    "locked": False,
                }
            ],
            "scored": True,
            "setup": "",
            "teardown": "",
            "type": "doctest"
        }
    ]
}
